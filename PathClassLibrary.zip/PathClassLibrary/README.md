# PathPlanning_PathTools_PathClassLibrary
This is the Path class library for MATLAB and listing of all functions within this class.

It depends on the following classes which can be found on the IVSG repo:

GPS.m
Map.m
